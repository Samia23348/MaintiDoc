# Historique des prompts du corpus — MaintiDoc

## État de traçabilité

Les deux archives sources ont été fournies directement par l'équipe. Aucun historique antérieur de recherche ou de génération n'était inclus dans les archives. Les formulations ci-dessous sont donc des **prompts de recherche/reconstitution proposés pour documenter la méthode**, et ne doivent pas être présentées comme des prompts réellement exécutés si ce n'est pas le cas. Compléter les dates, outils, URL et résultats après vérification par l'équipe.

## Famille 1 — Moniteur médical

1. « Rechercher des documents techniques fiables concernant le dépannage et la maintenance d'un moniteur multiparamétrique : écran noir, scintillement, ECG absent/bruité, électrodes déconnectées, SpO2 absente, pression non invasive, température, fréquence respiratoire, alarmes, batterie et ventilation. Privilégier les manuels fabricants, notices de maintenance et bulletins techniques. »
2. « Pour chaque document retenu, relever le fabricant, le modèle compatible, la référence/version, la date, le type de document, les symptômes couverts, les procédures et les avertissements de sécurité. »
3. « Vérifier que le document concerne bien un moniteur médical et qu'il ne s'agit pas d'un doublon ou d'une simple page commerciale. »

## Famille 2 — Pompe à perfusion Plum 360

1. « Rechercher des documents techniques concernant la pompe à perfusion Plum 360 et ses incidents : démarrage/écran, occlusion amont ou aval, air dans la ligne, débit, capteurs, cassette/set, porte, batterie, alarmes, fuite, bruit mécanique et erreurs système. Privilégier la documentation officielle du fabricant et les documents de maintenance autorisés. »
2. « Identifier pour chaque ressource le modèle exact, la version, la référence, la date, les symptômes traités, les étapes de vérification et les précautions. »
3. « Écarter les contenus non vérifiables, les doublons et les instructions destinées à contourner les sécurités de l'appareil. »

## Prompt de préparation de l'inventaire

« À partir de la liste des fichiers du corpus, produire un inventaire CSV avec un identifiant, la famille d'équipement, le nom du fichier, le format, le sujet apparent, la source et les points à vérifier. Ne pas déduire le contenu technique uniquement du nom du fichier. »

## 

